<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0
 */

$run_gran_blog_style = explode('_', run_gran_get_theme_option('blog_style'));
$run_gran_columns = empty($run_gran_blog_style[1]) ? 2 : max(2, $run_gran_blog_style[1]);
$run_gran_post_format = get_post_format();
$run_gran_post_format = empty($run_gran_post_format) ? 'standard' : str_replace('post-format-', '', $run_gran_post_format);
$run_gran_animation = run_gran_get_theme_option('blog_animation');

?><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_layout_portfolio post_layout_portfolio_'.esc_attr($run_gran_columns).' post_format_'.esc_attr($run_gran_post_format).(is_sticky() && !is_paged() ? ' sticky' : '') ); ?>
	<?php echo (!run_gran_is_off($run_gran_animation) ? ' data-animation="'.esc_attr(run_gran_get_animation_classes($run_gran_animation)).'"' : ''); ?>>
	<?php

	// Sticky label
	if ( is_sticky() && !is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	$run_gran_image_hover = run_gran_get_theme_option('image_hover');
	// Featured image
	run_gran_show_post_featured(array(
		'thumb_size' => run_gran_get_thumb_size(strpos(run_gran_get_theme_option('body_style'), 'full')!==false || $run_gran_columns < 3 
								? 'masonry-big' 
								: 'masonry'),
		'show_no_image' => true,
		'class' => $run_gran_image_hover == 'dots' ? 'hover_with_info' : '',
		'post_info' => $run_gran_image_hover == 'dots' ? '<div class="post_info">'.esc_html(get_the_title()).'</div>' : ''
	));
	?>
</article>
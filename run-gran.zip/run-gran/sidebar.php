<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0
 */

if (run_gran_sidebar_present()) {
	ob_start();
	$run_gran_sidebar_name = run_gran_get_theme_option('sidebar_widgets');
	run_gran_storage_set('current_sidebar', 'sidebar');
	if ( is_active_sidebar($run_gran_sidebar_name) ) {
		dynamic_sidebar($run_gran_sidebar_name);
	}
	$run_gran_out = trim(ob_get_contents());
	ob_end_clean();
	if (!empty($run_gran_out)) {
		$run_gran_sidebar_position = run_gran_get_theme_option('sidebar_position');
		?>
		<div class="sidebar <?php echo esc_attr($run_gran_sidebar_position); ?> widget_area<?php if (!run_gran_is_inherit(run_gran_get_theme_option('sidebar_scheme'))) echo ' scheme_'.esc_attr(run_gran_get_theme_option('sidebar_scheme')); ?>" role="complementary">
			<div class="sidebar_inner">
				<?php
				do_action( 'run_gran_action_before_sidebar' );
				run_gran_show_layout(preg_replace("/<\/aside>[\r\n\s]*<aside/", "</aside><aside", $run_gran_out));
				do_action( 'run_gran_action_after_sidebar' );
				?>
			</div><!-- /.sidebar_inner -->
		</div><!-- /.sidebar -->
		<?php
	}
}
?>
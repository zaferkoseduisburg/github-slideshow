<?php
/**
 * The template to display Admin notices
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0.1
 */
 
$run_gran_theme_obj = wp_get_theme();
?>
<div class="update-nag" id="run_gran_admin_notice">
	<h3 class="run_gran_notice_title"><?php
		// Translators: Add theme name and version to the 'Welcome' message
		echo esc_html(sprintf(__('Welcome to %1$s v.%2$s', 'run-gran'),
				$run_gran_theme_obj->name . (RUN_GRAN_THEME_FREE ? ' ' . __('Free', 'run-gran') : ''),
				$run_gran_theme_obj->version
				));
	?></h3>
	<?php
	if (!run_gran_exists_trx_addons()) {
		?><p><?php echo wp_kses_data(__('<b>Attention!</b> Plugin "ThemeREX Addons is required! Please, install and activate it!', 'run-gran')); ?></p><?php
	}
	?><p>
		<a href="<?php echo esc_url(admin_url().'themes.php?page=run_gran_about'); ?>" class="button button-primary"><i class="dashicons dashicons-nametag"></i> <?php
			// Translators: Add theme name
			echo esc_html(sprintf(__('About %s', 'run-gran'), $run_gran_theme_obj->name));
		?></a>
		<?php
		if (run_gran_get_value_gp('page')!='tgmpa-install-plugins') {
			?>
			<a href="<?php echo esc_url(admin_url().'themes.php?page=tgmpa-install-plugins'); ?>" class="button button-primary"><i class="dashicons dashicons-admin-plugins"></i> <?php esc_html_e('Install plugins', 'run-gran'); ?></a>
			<?php
		}
		if (function_exists('run_gran_exists_trx_addons') && run_gran_exists_trx_addons() && class_exists('trx_addons_demo_data_importer')) {
			?>
			<a href="<?php echo esc_url(admin_url().'themes.php?page=trx_importer'); ?>" class="button button-primary"><i class="dashicons dashicons-download"></i> <?php esc_html_e('One Click Demo Data', 'run-gran'); ?></a>
			<?php
		}
		?>
        <a href="<?php echo esc_url(admin_url().'customize.php'); ?>" class="button button-primary"><i class="dashicons dashicons-admin-appearance"></i> <?php esc_html_e('Theme Customizer', 'run-gran'); ?></a>
		<span> <?php esc_html_e('or', 'run-gran'); ?> </span>
        <a href="<?php echo esc_url(admin_url().'themes.php?page=theme_options'); ?>" class="button button-primary"><i class="dashicons dashicons-admin-appearance"></i> <?php esc_html_e('Theme Options', 'run-gran'); ?></a>
        <a href="#" class="button run_gran_hide_notice"><i class="dashicons dashicons-dismiss"></i> <?php esc_html_e('Hide Notice', 'run-gran'); ?></a>
	</p>
</div>
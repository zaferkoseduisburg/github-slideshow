<?php
/**
 * The template to display the site logo in the footer
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0.10
 */

// Logo
if (run_gran_is_on(run_gran_get_theme_option('logo_in_footer'))) {
	$run_gran_logo_image = '';
	if (run_gran_is_on(run_gran_get_theme_option('logo_retina_enabled')) && run_gran_get_retina_multiplier(2) > 1)
		$run_gran_logo_image = run_gran_get_theme_option( 'logo_footer_retina' );
	if (empty($run_gran_logo_image)) 
		$run_gran_logo_image = run_gran_get_theme_option( 'logo_footer' );
	$run_gran_logo_text   = get_bloginfo( 'name' );
	if (!empty($run_gran_logo_image) || !empty($run_gran_logo_text)) {
		?>
		<div class="footer_logo_wrap">
			<div class="footer_logo_inner">
				<?php
				if (!empty($run_gran_logo_image)) {
					$run_gran_attr = run_gran_getimagesize($run_gran_logo_image);
					echo '<a href="'.esc_url(home_url('/')).'"><img src="'.esc_url($run_gran_logo_image).'" class="logo_footer_image" alt="'.esc_attr__('icon', 'run-gran').'"'.(!empty($run_gran_attr[3]) ? ' ' . wp_kses_data($run_gran_attr[3]) : '').'></a>' ;
				} else if (!empty($run_gran_logo_text)) {
					echo '<h1 class="logo_footer_text"><a href="'.esc_url(home_url('/')).'">' . esc_html($run_gran_logo_text) . '</a></h1>';
				}
				?>
			</div>
		</div>
		<?php
	}
}
?>
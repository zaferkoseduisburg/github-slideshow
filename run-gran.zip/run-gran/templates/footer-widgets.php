<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0.10
 */

// Footer sidebar
$run_gran_footer_name = run_gran_get_theme_option('footer_widgets');
$run_gran_footer_present = !run_gran_is_off($run_gran_footer_name) && is_active_sidebar($run_gran_footer_name);
if ($run_gran_footer_present) { 
	run_gran_storage_set('current_sidebar', 'footer');
	$run_gran_footer_wide = run_gran_get_theme_option('footer_wide');
	ob_start();
	if ( is_active_sidebar($run_gran_footer_name) ) {
		dynamic_sidebar($run_gran_footer_name);
	}
	$run_gran_out = trim(ob_get_contents());
	ob_end_clean();
	if (!empty($run_gran_out)) {
		$run_gran_out = preg_replace("/<\\/aside>[\r\n\s]*<aside/", "</aside><aside", $run_gran_out);
		$run_gran_need_columns = true;
		if ($run_gran_need_columns) {
			$run_gran_columns = max(0, (int) run_gran_get_theme_option('footer_columns'));
			if ($run_gran_columns == 0) $run_gran_columns = min(4, max(1, substr_count($run_gran_out, '<aside ')));
			if ($run_gran_columns > 1){
				$run_gran_out = preg_replace("/class=\"widget /", "class=\"column-1_".esc_attr($run_gran_columns).' widget ', $run_gran_out);
            } else {
				$run_gran_need_columns = false;
            }
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo !empty($run_gran_footer_wide) ? ' footer_fullwidth' : ''; ?> sc_layouts_row  sc_layouts_row_type_normal">
			<div class="footer_widgets_inner widget_area_inner">
				<?php 
				if (!$run_gran_footer_wide) { 
					?><div class="content_wrap"><?php
				}
				if ($run_gran_need_columns) {
					?><div class="columns_wrap"><?php
				}
				do_action( 'run_gran_action_before_sidebar' );
				run_gran_show_layout($run_gran_out);
				do_action( 'run_gran_action_after_sidebar' );
				if ($run_gran_need_columns) {
					?></div><!-- /.columns_wrap --><?php
				}
				if (!$run_gran_footer_wide) {
					?></div><!-- /.content_wrap --><?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
?>
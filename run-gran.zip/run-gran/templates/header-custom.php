<?php
/**
 * The template to display custom header from the ThemeREX Addons Layouts
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0.06
 */

$run_gran_header_css = $run_gran_header_image = '';
$run_gran_header_video = run_gran_get_header_video();
if (true || empty($run_gran_header_video)) {
	$run_gran_header_image = get_header_image();
	if (run_gran_trx_addons_featured_image_override(true)) $run_gran_header_image = run_gran_get_current_mode_image($run_gran_header_image);
}

$run_gran_header_id = str_replace('header-custom-', '', run_gran_get_theme_option("header_style"));
if ((int) $run_gran_header_id == 0) {
	$run_gran_header_id = run_gran_get_post_id(array(
												'name' => $run_gran_header_id,
												'post_type' => defined('TRX_ADDONS_CPT_LAYOUT_PT') ? TRX_ADDONS_CPT_LAYOUT_PT : 'cpt_layouts'
												)
											);
} else {
	$run_gran_header_id = apply_filters('run_gran_filter_get_translated_layout', $run_gran_header_id);
}
$run_gran_header_meta = get_post_meta($run_gran_header_id, 'trx_addons_options', true);

?><header class="top_panel top_panel_custom top_panel_custom_<?php echo esc_attr($run_gran_header_id); 
				?> top_panel_custom_<?php echo esc_attr(sanitize_title(get_the_title($run_gran_header_id)));
				echo !empty($run_gran_header_image) || !empty($run_gran_header_video) 
					? ' with_bg_image' 
					: ' without_bg_image';
				if ($run_gran_header_video!='') 
					echo ' with_bg_video';
				if ($run_gran_header_image!='') 
					echo ' '.esc_attr(run_gran_add_inline_css_class('background-image: url('.esc_url($run_gran_header_image).');'));
				if (!empty($run_gran_header_meta['margin']) != '') 
					echo ' '.esc_attr(run_gran_add_inline_css_class('margin-bottom: '.esc_attr(run_gran_prepare_css_value($run_gran_header_meta['margin'])).';'));
				if (is_single() && has_post_thumbnail()) 
					echo ' with_featured_image';
				if (run_gran_is_on(run_gran_get_theme_option('header_fullheight'))) 
					echo ' header_fullheight run_gran-full-height';
				?> scheme_<?php echo esc_attr(run_gran_is_inherit(run_gran_get_theme_option('header_scheme')) 
												? run_gran_get_theme_option('color_scheme') 
												: run_gran_get_theme_option('header_scheme'));
				?>"><?php

	// Background video
	if (!empty($run_gran_header_video)) {
		get_template_part( 'templates/header-video' );
	}
		
	// Custom header's layout
	do_action('run_gran_action_show_layout', $run_gran_header_id);

	// Header widgets area
	get_template_part( 'templates/header-widgets' );
		
?></header>
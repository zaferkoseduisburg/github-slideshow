<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0
 */

$run_gran_args = get_query_var('run_gran_logo_args');

// Site logo
$run_gran_logo_type   = isset($run_gran_args['type']) ? $run_gran_args['type'] : '';
$run_gran_logo_image  = run_gran_get_logo_image($run_gran_logo_type);
$run_gran_logo_text   = run_gran_is_on(run_gran_get_theme_option('logo_text')) ? get_bloginfo( 'name' ) : '';
$run_gran_logo_slogan = get_bloginfo( 'description', 'display' );
if (!empty($run_gran_logo_image) || !empty($run_gran_logo_text)) {
	?><a class="sc_layouts_logo" href="<?php echo is_front_page() ? '#' : esc_url(home_url('/')); ?>"><?php
		if (!empty($run_gran_logo_image)) {
			if (empty($run_gran_logo_type) && function_exists('the_custom_logo') && (int) $run_gran_logo_image > 0) {
				the_custom_logo();
			} else {
				$run_gran_attr = run_gran_getimagesize($run_gran_logo_image);
				echo '<img src="'.esc_url($run_gran_logo_image).'" alt="'.esc_attr__('icon', 'run-gran').'"'.(!empty($run_gran_attr[3]) ? ' '.wp_kses_data($run_gran_attr[3]) : '').'>';
			}
		} else {
			run_gran_show_layout(run_gran_prepare_macros($run_gran_logo_text), '<span class="logo_text">', '</span>');
			run_gran_show_layout(run_gran_prepare_macros($run_gran_logo_slogan), '<span class="logo_slogan">', '</span>');
		}
	?></a><?php
}
?>
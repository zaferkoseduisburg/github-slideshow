<?php
/**
 * The template to display menu in the footer
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0.10
 */

// Footer menu
$run_gran_menu_footer = run_gran_get_nav_menu(array(
											'location' => 'menu_footer',
											'class' => 'sc_layouts_menu sc_layouts_menu_default'
											));
if (!empty($run_gran_menu_footer)) {
	?>
	<div class="footer_menu_wrap">
		<div class="footer_menu_inner">
			<?php run_gran_show_layout($run_gran_menu_footer); ?>
		</div>
	</div>
	<?php
}
?>
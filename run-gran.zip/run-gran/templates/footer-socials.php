<?php
/**
 * The template to display the socials in the footer
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0.10
 */


// Socials
if ( run_gran_is_on(run_gran_get_theme_option('socials_in_footer')) && ($run_gran_output = run_gran_get_socials_links()) != '') {
	?>
	<div class="footer_socials_wrap socials_wrap">
		<div class="footer_socials_inner">
			<?php run_gran_show_layout($run_gran_output); ?>
		</div>
	</div>
	<?php
}
?>
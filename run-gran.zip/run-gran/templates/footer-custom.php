<?php
/**
 * The template to display default site footer
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0.10
 */

$run_gran_footer_scheme =  run_gran_is_inherit(run_gran_get_theme_option('footer_scheme')) ? run_gran_get_theme_option('color_scheme') : run_gran_get_theme_option('footer_scheme');
$run_gran_footer_id = str_replace('footer-custom-', '', run_gran_get_theme_option("footer_style"));
if ((int) $run_gran_footer_id == 0) {
	$run_gran_footer_id = run_gran_get_post_id(array(
												'name' => $run_gran_footer_id,
												'post_type' => defined('TRX_ADDONS_CPT_LAYOUT_PT') ? TRX_ADDONS_CPT_LAYOUT_PT : 'cpt_layouts'
												)
											);
} else {
	$run_gran_footer_id = apply_filters('run_gran_filter_get_translated_layout', $run_gran_footer_id);
}
$run_gran_footer_meta = get_post_meta($run_gran_footer_id, 'trx_addons_options', true);
?>
<footer class="footer_wrap footer_custom footer_custom_<?php echo esc_attr($run_gran_footer_id); 
						?> footer_custom_<?php echo esc_attr(sanitize_title(get_the_title($run_gran_footer_id))); 
						if (!empty($run_gran_footer_meta['margin']) != '') 
							echo ' '.esc_attr(run_gran_add_inline_css_class('margin-top: '.run_gran_prepare_css_value($run_gran_footer_meta['margin']).';'));
						?> scheme_<?php echo esc_attr($run_gran_footer_scheme); 
						?>">
	<?php
    // Custom footer's layout
    do_action('run_gran_action_show_layout', $run_gran_footer_id);
	?>
</footer><!-- /.footer_wrap -->

<?php
// Add plugin-specific colors and fonts to the custom CSS
if (!function_exists('run_gran_mailchimp_get_css')) {
	add_filter('run_gran_filter_get_css', 'run_gran_mailchimp_get_css', 10, 4);
	function run_gran_mailchimp_get_css($css, $colors, $fonts, $scheme='') {
		
		if (isset($css['fonts']) && $fonts) {
			$css['fonts'] .= <<<CSS

CSS;
		
			
			$rad = run_gran_get_border_radius();
			$css['fonts'] .= <<<CSS



CSS;
		}

		
		if (isset($css['colors']) && $colors) {
			$css['colors'] .= <<<CSS

.mc4wp-form input[type="email"] {
	border-color: {$colors['alter_dark_03']};
	color: {$colors['bg_color']};
}
.mc4wp-form .mc4wp-alert {
	border-color: {$colors['text_hover']};
	color: {$colors['inverse_text']};
}


.mc4wp-form .mc4wp-form-fields input[type="email"]::-webkit-input-placeholder {opacity: 1;color: {$colors['alter_dark']};}
.mc4wp-form .mc4wp-form-fields input[type="email"]::-moz-placeholder          {opacity: 1;color: {$colors['alter_dark']};}
.mc4wp-form .mc4wp-form-fields input[type="email"]:-moz-placeholder           {opacity: 1;color: {$colors['alter_dark']};}
.mc4wp-form .mc4wp-form-fields input[type="email"]:-ms-input-placeholder     {opacity: 1;color: {$colors['alter_dark']};}



CSS;
		}

		return $css;
	}
}
?>
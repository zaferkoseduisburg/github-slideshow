<div class="front_page_section front_page_section_subscribe<?php
			$run_gran_scheme = run_gran_get_theme_option('front_page_subscribe_scheme');
			if (!run_gran_is_inherit($run_gran_scheme)) echo ' scheme_'.esc_attr($run_gran_scheme);
			echo ' front_page_section_paddings_'.esc_attr(run_gran_get_theme_option('front_page_subscribe_paddings'));
		?>"<?php
		$run_gran_css = '';
		$run_gran_bg_image = run_gran_get_theme_option('front_page_subscribe_bg_image');
		if (!empty($run_gran_bg_image)) 
			$run_gran_css .= 'background-image: url('.esc_url(run_gran_get_attachment_url($run_gran_bg_image)).');';
		if (!empty($run_gran_css))
			echo ' style="' . esc_attr($run_gran_css) . '"';
?>><?php
	// Add anchor
	$run_gran_anchor_icon = run_gran_get_theme_option('front_page_subscribe_anchor_icon');	
	$run_gran_anchor_text = run_gran_get_theme_option('front_page_subscribe_anchor_text');	
	if ((!empty($run_gran_anchor_icon) || !empty($run_gran_anchor_text)) && shortcode_exists('trx_sc_anchor')) {
		echo do_shortcode('[trx_sc_anchor id="front_page_section_subscribe"'
										. (!empty($run_gran_anchor_icon) ? ' icon="'.esc_attr($run_gran_anchor_icon).'"' : '')
										. (!empty($run_gran_anchor_text) ? ' title="'.esc_attr($run_gran_anchor_text).'"' : '')
										. ']');
	}
	?>
	<div class="front_page_section_inner front_page_section_subscribe_inner<?php
			if (run_gran_get_theme_option('front_page_subscribe_fullheight'))
				echo ' run_gran-full-height sc_layouts_flex sc_layouts_columns_middle';
			?>"<?php
			$run_gran_css = '';
			$run_gran_bg_mask = run_gran_get_theme_option('front_page_subscribe_bg_mask');
			$run_gran_bg_color = run_gran_get_theme_option('front_page_subscribe_bg_color');
			if (!empty($run_gran_bg_color) && $run_gran_bg_mask > 0)
				$run_gran_css .= 'background-color: '.esc_attr($run_gran_bg_mask==1
																	? $run_gran_bg_color
																	: run_gran_hex2rgba($run_gran_bg_color, $run_gran_bg_mask)
																).';';
			if (!empty($run_gran_css))
				echo ' style="' . esc_attr($run_gran_css) . '"';
	?>>
		<div class="front_page_section_content_wrap front_page_section_subscribe_content_wrap content_wrap">
			<?php
			// Caption
			$run_gran_caption = run_gran_get_theme_option('front_page_subscribe_caption');
			if (!empty($run_gran_caption) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><h2 class="front_page_section_caption front_page_section_subscribe_caption front_page_block_<?php echo !empty($run_gran_caption) ? 'filled' : 'empty'; ?>"><?php echo wp_kses_post($run_gran_caption); ?></h2><?php
			}
		
			// Description (text)
			$run_gran_description = run_gran_get_theme_option('front_page_subscribe_description');
			if (!empty($run_gran_description) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><div class="front_page_section_description front_page_section_subscribe_description front_page_block_<?php echo !empty($run_gran_description) ? 'filled' : 'empty'; ?>"><?php echo wp_kses_post(wpautop($run_gran_description)); ?></div><?php
			}
			
			// Content
			$run_gran_sc = run_gran_get_theme_option('front_page_subscribe_shortcode');
			if (!empty($run_gran_sc) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><div class="front_page_section_output front_page_section_subscribe_output front_page_block_<?php echo !empty($run_gran_sc) ? 'filled' : 'empty'; ?>"><?php
					run_gran_show_layout(do_shortcode($run_gran_sc));
				?></div><?php
			}
			?>
		</div>
	</div>
</div>
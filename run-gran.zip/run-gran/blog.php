<?php
/**
 * The template to display blog archive
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0
 */

/*
Template Name: Blog archive
*/

/**
 * Make page with this template and put it into menu
 * to display posts as blog archive
 * You can setup output parameters (blog style, posts per page, parent category, etc.)
 * in the Theme Options section (under the page content)
 * You can build this page in the WordPress editor or any Page Builder to make custom page layout:
 * just insert %%CONTENT%% in the desired place of content
 */

// Get template page's content
$run_gran_content = '';
$run_gran_blog_archive_mask = '%%CONTENT%%';
$run_gran_blog_archive_subst = sprintf('<div class="blog_archive">%s</div>', $run_gran_blog_archive_mask);
if ( have_posts() ) {
	the_post();
	if (($run_gran_content = apply_filters('the_content', get_the_content())) != '') {
		if (($run_gran_pos = strpos($run_gran_content, $run_gran_blog_archive_mask)) !== false) {
			$run_gran_content = preg_replace('/(\<p\>\s*)?'.$run_gran_blog_archive_mask.'(\s*\<\/p\>)/i', $run_gran_blog_archive_subst, $run_gran_content);
		} else
			$run_gran_content .= $run_gran_blog_archive_subst;
		$run_gran_content = explode($run_gran_blog_archive_mask, $run_gran_content);
		// Add VC custom styles to the inline CSS
		$vc_custom_css = get_post_meta( get_the_ID(), '_wpb_shortcodes_custom_css', true );
		if ( !empty( $vc_custom_css ) ) run_gran_add_inline_css(strip_tags($vc_custom_css));
	}
}

// Prepare args for a new query
$run_gran_args = array(
	'post_status' => current_user_can('read_private_pages') && current_user_can('read_private_posts') ? array('publish', 'private') : 'publish'
);
$run_gran_args = run_gran_query_add_posts_and_cats($run_gran_args, '', run_gran_get_theme_option('post_type'), run_gran_get_theme_option('parent_cat'));
$run_gran_page_number = get_query_var('paged') ? get_query_var('paged') : (get_query_var('page') ? get_query_var('page') : 1);
if ($run_gran_page_number > 1) {
	$run_gran_args['paged'] = $run_gran_page_number;
	$run_gran_args['ignore_sticky_posts'] = true;
}
$run_gran_ppp = run_gran_get_theme_option('posts_per_page');
if ((int) $run_gran_ppp != 0)
	$run_gran_args['posts_per_page'] = (int) $run_gran_ppp;
// Make a new main query
$GLOBALS['wp_the_query']->query($run_gran_args);


// Add internal query vars in the new query!
if (is_array($run_gran_content) && count($run_gran_content) == 2) {
	set_query_var('blog_archive_start', $run_gran_content[0]);
	set_query_var('blog_archive_end', $run_gran_content[1]);
}

get_template_part('index');
?>
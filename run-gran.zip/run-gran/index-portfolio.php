<?php
/**
 * The template for homepage posts with "Portfolio" style
 *
 * @package WordPress
 * @subpackage RUN_GRAN
 * @since RUN_GRAN 1.0
 */

run_gran_storage_set('blog_archive', true);

get_header(); 

if (have_posts()) {

	run_gran_show_layout(get_query_var('blog_archive_start'));

	$run_gran_stickies = is_home() ? get_option( 'sticky_posts' ) : false;
	$run_gran_sticky_out = run_gran_get_theme_option('sticky_style')=='columns' 
							&& is_array($run_gran_stickies) && count($run_gran_stickies) > 0 && get_query_var( 'paged' ) < 1;
	
	// Show filters
	$run_gran_cat = run_gran_get_theme_option('parent_cat');
	$run_gran_post_type = run_gran_get_theme_option('post_type');
	$run_gran_taxonomy = run_gran_get_post_type_taxonomy($run_gran_post_type);
	$run_gran_show_filters = run_gran_get_theme_option('show_filters');
	$run_gran_tabs = array();
	if (!run_gran_is_off($run_gran_show_filters)) {
		$run_gran_args = array(
			'type'			=> $run_gran_post_type,
			'child_of'		=> $run_gran_cat,
			'orderby'		=> 'name',
			'order'			=> 'ASC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 0,
			'exclude'		=> '',
			'include'		=> '',
			'number'		=> '',
			'taxonomy'		=> $run_gran_taxonomy,
			'pad_counts'	=> false
		);
		$run_gran_portfolio_list = get_terms($run_gran_args);
		if (is_array($run_gran_portfolio_list) && count($run_gran_portfolio_list) > 0) {
			$run_gran_tabs[$run_gran_cat] = esc_html__('All', 'run-gran');
			foreach ($run_gran_portfolio_list as $run_gran_term) {
				if (isset($run_gran_term->term_id)) $run_gran_tabs[$run_gran_term->term_id] = $run_gran_term->name;
			}
		}
	}
	if (count($run_gran_tabs) > 0) {
		$run_gran_portfolio_filters_ajax = true;
		$run_gran_portfolio_filters_active = $run_gran_cat;
		$run_gran_portfolio_filters_id = 'portfolio_filters';
		if (!is_customize_preview())
			wp_enqueue_script('jquery-ui-tabs', false, array('jquery', 'jquery-ui-core'), null, true);
		?>
		<div class="portfolio_filters run_gran_tabs run_gran_tabs_ajax">
			<ul class="portfolio_titles run_gran_tabs_titles">
				<?php
				foreach ($run_gran_tabs as $run_gran_id=>$run_gran_title) {
					?><li><a href="<?php echo esc_url(run_gran_get_hash_link(sprintf('#%s_%s_content', $run_gran_portfolio_filters_id, $run_gran_id))); ?>" data-tab="<?php echo esc_attr($run_gran_id); ?>"><?php echo esc_html($run_gran_title); ?></a></li><?php
				}
				?>
			</ul>
			<?php
			$run_gran_ppp = run_gran_get_theme_option('posts_per_page');
			if (run_gran_is_inherit($run_gran_ppp)) $run_gran_ppp = '';
			foreach ($run_gran_tabs as $run_gran_id=>$run_gran_title) {
				$run_gran_portfolio_need_content = $run_gran_id==$run_gran_portfolio_filters_active || !$run_gran_portfolio_filters_ajax;
				?>
				<div id="<?php echo esc_attr(sprintf('%s_%s_content', $run_gran_portfolio_filters_id, $run_gran_id)); ?>"
					class="portfolio_content run_gran_tabs_content"
					data-blog-template="<?php echo esc_attr(run_gran_storage_get('blog_template')); ?>"
					data-blog-style="<?php echo esc_attr(run_gran_get_theme_option('blog_style')); ?>"
					data-posts-per-page="<?php echo esc_attr($run_gran_ppp); ?>"
					data-post-type="<?php echo esc_attr($run_gran_post_type); ?>"
					data-taxonomy="<?php echo esc_attr($run_gran_taxonomy); ?>"
					data-cat="<?php echo esc_attr($run_gran_id); ?>"
					data-parent-cat="<?php echo esc_attr($run_gran_cat); ?>"
					data-need-content="<?php echo (false===$run_gran_portfolio_need_content ? 'true' : 'false'); ?>"
				>
					<?php
					if ($run_gran_portfolio_need_content) 
						run_gran_show_portfolio_posts(array(
							'cat' => $run_gran_id,
							'parent_cat' => $run_gran_cat,
							'taxonomy' => $run_gran_taxonomy,
							'post_type' => $run_gran_post_type,
							'page' => 1,
							'sticky' => $run_gran_sticky_out
							)
						);
					?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	} else {
		run_gran_show_portfolio_posts(array(
			'cat' => $run_gran_cat,
			'parent_cat' => $run_gran_cat,
			'taxonomy' => $run_gran_taxonomy,
			'post_type' => $run_gran_post_type,
			'page' => 1,
			'sticky' => $run_gran_sticky_out
			)
		);
	}

	run_gran_show_layout(get_query_var('blog_archive_end'));

} else {

	if ( is_search() )
		get_template_part( 'content', 'none-search' );
	else
		get_template_part( 'content', 'none-archive' );

}

get_footer();
?>